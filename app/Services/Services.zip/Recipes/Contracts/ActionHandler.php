<?php

namespace App\Services\Recipes\Contracts;

use App\Models\RecipeAction;
use App\Models\RecipeRun;

interface ActionHandler
{
    /** Return true if this handler can handle $type (e.g. 'add_mailaccount'). */
    public function supports(string $type): bool;

    /**
     * Execute the action.
     * Return a normalized array like: ['success'=>bool, 'Response'=>mixed] (or include 'error').
     */
    public function handle(RecipeAction $action, RecipeRun $run, array $vars, bool $dryRun = false): array;
}
