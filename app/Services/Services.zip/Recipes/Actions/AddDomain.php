<?php

namespace App\Services\Recipes\Actions;

use App\Models\RecipeAction;
use App\Models\RecipeRun;
use App\Services\Recipes\Contracts\ActionHandler;
use App\Services\Recipes\KasGateway;

class AddDomain implements ActionHandler
{
    public function __construct(private KasGateway $kas) {}

    public function supports(string $type): bool
    {
        return $type === 'add_domain';
    }

    public function handle(RecipeAction $action, RecipeRun $run, array $vars, bool $dryRun = false): array
    {
        if ($dryRun) return ['success'=>true,'dry_run'=>true];

        $login  = $vars['kas_login']   ?? $run->kas_login;
        $domain = $vars['domain_name'] ?? $run->domain_name;
        $php    = $vars['php_version'] ?? $action->parameters['php_version'] ?? '8.3';

        $payload = ['domain' => $domain, 'php_version' => $php];
        return $this->kas->callForLogin($login, 'add_domain', $payload);
    }
}
