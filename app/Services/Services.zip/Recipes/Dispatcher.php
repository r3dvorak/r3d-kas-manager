<?php

namespace App\Services\Recipes;

use App\Models\RecipeAction;
use App\Models\RecipeRun;
use App\Services\Recipes\Contracts\ActionHandler;

class Dispatcher
{
    /** @var ActionHandler[] */
    protected array $handlers;

    public function __construct(iterable $handlers)
    {
        // allow $handlers to be a generator/iterable from container
        $this->handlers = is_array($handlers) ? $handlers : iterator_to_array($handlers);
    }

    public function dispatch(RecipeAction $action, RecipeRun $run, array $vars, bool $dryRun = false): array
    {
        foreach ($this->handlers as $h) {
            if ($h->supports($action->type)) {
                return $h->handle($action, $run, $vars, $dryRun);
            }
        }
        return ['success' => false, 'error' => "Unknown action: {$action->type}"];
    }
}
