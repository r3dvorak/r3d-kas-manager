<?php

namespace App\Services\Recipes;

use App\Models\KasClient;
use SoapClient;
use Exception;

class KasGateway
{
    /** Low-level call: requires raw login + encrypted password from model. */
    public function call(string $kasLogin, string $encryptedPassword, string $action, array $params = []): array
    {
        $wsdl = 'https://kasapi.kasserver.com/soap/wsdl/KasApi.wsdl';
        $soap = new SoapClient($wsdl, [
            'exceptions' => true,
            'cache_wsdl' => WSDL_CACHE_NONE,
            'trace'      => true,
            'features'   => SOAP_SINGLE_ELEMENT_ARRAYS,
        ]);

        $payload = [
            'kas_login'        => $kasLogin,
            'kas_auth_type'    => 'plain',
            'kas_auth_data'    => $encryptedPassword, // model stores encrypted, KasApi accepts the decrypted value (your model accessor should handle)
            'kas_action'       => $action,
            'KasRequestParams' => $params,
        ];
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        try {
            $raw = $soap->__soapCall('KasApi', [$json]);
            if (is_string($raw)) {
                $d = json_decode($raw, true);
                $raw = (json_last_error() === JSON_ERROR_NONE && is_array($d)) ? $d : ['Response' => ['Raw' => $raw]];
            } elseif (is_object($raw)) {
                $raw = json_decode(json_encode($raw), true) ?? [];
            } elseif (!is_array($raw)) {
                $raw = ['Response' => ['Raw' => $raw]];
            }
            $resp = $raw['Response'] ?? $raw;
            $ok   = (string)($resp['ReturnString'] ?? $raw['ReturnString'] ?? 'TRUE') === 'TRUE';

            return ['success' => $ok, 'Response' => $resp];
        } catch (\SoapFault $e) {
            $msg = $e->faultstring ?? $e->getMessage();
            if (stripos($msg, 'flood_protection') !== false) {
                sleep(2);
                $raw = $soap->__soapCall('KasApi', [$json]);
                $raw = is_object($raw) ? json_decode(json_encode($raw), true) : (array)$raw;
                return ['success' => true, 'Response' => ($raw['Response'] ?? $raw)];
            }
            return ['success' => false, 'error' => "KAS SOAP error: {$msg}"];
        } catch (\Throwable $e) {
            return ['success' => false, 'error' => "KAS SOAP error: ".$e->getMessage()];
        }
    }

    /** Convenience: resolves KasClient by login and calls. */
    public function callForLogin(string $kasLogin, string $action, array $params = []): array
    {
        $client = KasClient::where('account_login', $kasLogin)->firstOrFail();
        return $this->call($kasLogin, $client->account_password, $action, $params);
    }
}
